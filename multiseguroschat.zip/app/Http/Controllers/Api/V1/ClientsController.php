<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Invoices;
use Illuminate\Http\Request;

class ClientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //  return $request->passportnumber;
       $client = new Client();
       $client->name = strtoupper($request->name);
       $client->lastname = strtoupper($request->lastname);
       $client->cardnumber = $request->cardnumber;
       $client->passportnumber = $request->passportnumber;
       $client->phonenumber = $request->phonenumber;
       $client->adrress = strtoupper($request->adrress);
       $client->city = strtoupper($request->city);
       $client->province = 33;
       $client->nacionalidad = 117;
       $client->email = $request->email;
       $client->idConversacion = $request->idConversacion;
       $client->save();

       if($client){
            return ['status' => '00', 'message' => 'Usuario creado correctamente'];
        }else{
            return ['status' => '01', 'message' => 'No tiene póliza registrada'];
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function show($id, $idConversacion)
    {
        $client = Client::where('phonenumber', $id)->first();
       // return $client;
        $client->idConversacion = $idConversacion;
        $client->save();
       
        if($client){
            return [
                    'status' => '00', 
                    'id' => $client->id,
                    'name' => $client->name,
                    'lastname' => $client->lastname,
                    'cardnumber' => $client->cardnumber,
                    'passportnumber' => $client->passportnumber,
                    'phonenumber' => $client->phonenumber,
                    'adrress' => $client->adrress,
                    'city' => $client->city,
                    'email' => $client->email,
                  ];
        }else{
            return ['status' => '01', 'message' => 'El cliente no se encuentra registrado'];
        }

    }

    public function update(Request $request, Client $client)
    {
        //
    }

    public function destroy(Client $client)
    {
        //
    }

    public function clientPilicy($cedula)
    {
        $invoince = Invoices::where([['client_id', $cedula],['payment_status', 'ACCEPT']])->get()->last();
        if($invoince){
            return ['status' => '00', 'url' => 'https://multiseguros.com.do/Seg_V2Dev/ticket.php?id='.$invoince->police_transactionId];
        }else{
            return ['status' => '01', 'message' => 'No tiene póliza registrada'];
        }
    }
    public function codigosDescuento(Request $request){
        
    }



}
