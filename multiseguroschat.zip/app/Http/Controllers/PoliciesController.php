<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Discounts;
use App\Models\Insurance;
use App\Models\Invoices;
use App\Models\Price;
use App\Models\Service;
use App\Models\Vehicle_brands;
use App\Models\Vehicle_models;
use App\Models\Vehicle_type_tarif;
use Inertia\Inertia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Stmt\Return_;

use function PHPUnit\Framework\isEmpty;
use function PHPUnit\Framework\isNull;

class PoliciesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $marcaid)
    {
        $tipo= '';
        $tipoName = '';
        $modelo = '';
        $modeloName = '';
        $marca = '';
        $marcaName = '';
        //return $request->modelos;
        // Si llegan string no realiza la búsqueda del nombre porque ya viene en la variable base
        if(!is_string($request->tipo)){
            foreach($request->tipos as $tipo){
                if($tipo['id'] == $request->tipo ){
                   $tipoName = $tipo['nombre'];
                   break;
                }
            }
        }else{
            $tipoName = $request->tipo;
        }
        if(!is_string($request->modelo)){
            foreach($request->modelos as $modelo){
                if($modelo['ID'] == $request->modelo ){
                    $modeloName = $modelo['descripcion'];
                   break;
                }
            }
        }else{
            $modeloName = $request->modelo;
        }

        foreach($request->marcas as $marca){
            if($marca['ID'] == $marcaid ){
                $marcaName = $marca['DESCRIPCION'];
                $marcaid = $marca['ID'];
               break;
            }
        }
        //Validar si el valor de tipo, modelo y marca viene del edit, para poder porcesar el ID de cada uno
        if(is_int($request->tipo) and is_int($marcaid) and is_int($request->modelo) ){
            $car = array(
                'tipo' => $request->tipo,
                'tipoName' => $tipoName,
                'marca' => $marcaid,
                'marcaName' => $marcaName,
                'modelo' => $request->modelo,
                'modeloName' => $modeloName,
                'placa' => $request->placa,
                'chasis' => $request->chasis,
                'year' => $request->year,
            );
        }else{
            $car = array(
                'tipo' => '',
                'tipoName' => $tipoName,
                'marca' => '',
                'marcaName' => $marcaName,
                'modelo' => '',
                'modeloName' => $modeloName,
                'placa' => $request->placa,
                'chasis' => $request->chasis,
                'year' => $request->year,
            );
            if(is_string($request->tipo)){
                foreach($request->tipos as $tipo){
                    if($tipo['nombre'] == $request->tipo ){
                        $car['tipo'] = $tipo['id'];
                        break;
                    }
                };
            }else{
                $car['tipo'] = $request->tipo;
            }
            if(is_string($marcaid)){
                foreach($request->marcas as $marca){
                    if($marca['DESCRIPCION'] == $marcaid ){
                        $car['marcaName'] = $marcaid;
                        $car['marca'] = $marca['ID'];
                        break;
                    }
                }
            }
            if(is_string($request->modelo)){
                foreach($request->modelos as $modelo){
                    if($modelo['descripcion'] == $request->modelo ){
                        $car['modelo'] = $modelo['ID'];
                        break;
                    }
                }
            }
        }
        $seller = DB::table('insurances')
            ->join('prices', 'prices.insurances_id', 'insurances.id')
            ->join('vehicle_type_tarifs', 'vehicle_type_tarifs.id', 'prices.vehicle_type_id')
            ->join('data_payment_gateway', 'insurances.id', 'data_payment_gateway.insurance_id')
            ->join('payment_gateway', 'data_payment_gateway.payment_gateway_id', 'payment_gateway.id')
            ->where([['insurances.activo', 'si'], ['vehicle_type_tarifs.id', $car['tipo']]])
            ->select(
                'insurances.nombre AS insurace',
                'prefijo',
                'logo',
                'color',
                'priceThreeMonths AS tresmeses',
                'priceSixMonths AS seismeses',
                'priceTwelveMonths AS docemeses',
                'vehicle_type_tarifs.nombre AS vehicle_type',
                'insurances.id AS insurances_id',
                'vehicle_type_tarifs.id_serv AS servicios',
                'payment_gateway.value AS payment_gateway',
                'merchanttype',
                'merchantnumber',
                'merchantterminal',
                'client_name',
                'vehicle_type_id'
            )
            ->get();

        return Inertia::render('Policy/index', [
            'car' => $car,
            'sellers' => $seller,
            'clien_id' => $request->clien_id,
            'cities' => $request->cities,
            'provinces' => $request->provinces,
            'clientProvince' => $request->clientProvince,
            'client' => $request->client,
            'tipos' => $request->tipos, 
            'modelos' => $request->modelos,
            'marcas' => $request->marcas
        ]);
    }

    public function show(Request $request)
    {
        $service = array();
        $totalServicios = 0;
        $sericesId = '';
        $clente = Client::find($request->clien_id);
        $tipo = Vehicle_type_tarif::find($request->car['tipo']);
        $marca = Vehicle_brands::find($request->car['marca']);
        $modelo = Vehicle_models::find($request->car['modelo']);
        $price = Price::where([['insurances_id', $request->insurre['insurance_id']], ['vehicle_type_id', $request->car['tipo']]])->get();
        foreach ($request->servicios as $serviciosActivo) {
            foreach ($request->services as $servicio) {
                if ($servicio['id'] == $serviciosActivo) {
                    $totalServicios = $totalServicios + $servicio['servicePrice'];
                    array_push($service, $servicio);
                }
            }
        }
       //    return $services;
        if ($request->policyTime == 'tresmeses') {
            $policyTime = '3 Meses';
            $time = 'priceThreeMonths';
        } elseif ($request->policyTime == 'seismeses') {
            $policyTime = '6 Meses';
            $time = 'priceSixMonths';
        } else {
            $policyTime = '12 Meses';
            $time = 'priceTwelveMonths';
        }
        //$totalGeneral = $totalServicios + $request->seller[0][$time];
        $totalGeneral = $totalServicios + $price[0][$time];

        return Inertia::render('Policy/edit', [
            'car' => $request->car,
            'tarifa' => $request->tarifa,
            'sellers' => $request->sellers,
            'seller' => $request->sellers[0],
            'totalGeneral' => $totalGeneral,
            'policyTime' => $policyTime,
            'marca' => $marca['DESCRIPCION'],
            'tipo' => $tipo['nombre'],
            'modelo' => $modelo['descripcion'],
            'cliente' => $clente,
            'service' => $service,
            'services' => $request->services,
            'insurre' => $request->insurre,
            'client' => $request->client,
            'tipos' => $request->tipos, 
            'modelos' => $request->modelos,
            'marcas' => $request->marcas,
            'polizaValor' => $request->polizaValor,
            'clientProvince' => $request->clientProvince,
            'provinces' => $request->provinces,
            'cities' => $request->cities,
            

        ]);
    }

    public function confirm(Request $request)
    {
        //Traer los coddigos de descuentos activos
        $codigosDescuento = Discounts::where('active', '1')->get();
        return Inertia::render('Policy/approve',[
            'car' => $request->car,
            'tarifa' => $request->tarifa,
            'sellers' => $request->seller,
            'services' => $request->services,
            'policyTime' => $request->policyTime,
            'marca' => $request->marca,
            'totalGeneral' => $request->totalGeneral,
            'tipo' => $request->tipo,
            'modelo' => $request->modelo,
            'cliente' => $request->client,
            'insurre' => $request->insurre,
            'client' => $request->client,
            'tipos' => $request->tipos, 
            'marcas' => $request->marcas,
            'modelos' => $request->modelos,
            'codigosDescuento' => $codigosDescuento,
        ]);
    }


    public function services($insurresId, $time, Request $request)
    {
        $plazo ='';
        if ($time == '') {
            return 'Debes seleccionar un tiempo de vigencia de la póliza ';
        }
        $tarifaServices = explode("-", $request->servicios);
        $services = array();
        $servicios = Service::all();
        if($time == 'tresmeses'){
            $plazo = '3 meses';
        }
        if($time == 'seismeses'){
            $plazo = '6 meses';
        }
        if($time == 'docemeses'){
            $plazo = '12 meses';
        }
        foreach ($tarifaServices as $service) {
            foreach ($servicios as $servicio) {
                if ($servicio['id'] == $service) {
                    $service2 = array(
                        'serviceName' => $servicio['nombre'],
                        'servicePrice' => $servicio[$time],
                        'id' => $servicio['id'],
                        'time' => $plazo
                    );
                    array_push($services, $service2);
                }
            }
        }
        $insurres = DB::table('insurances')
            ->join('data_payment_gateway', 'insurances.id', 'data_payment_gateway.insurance_id')
            ->where('insurances.id', $insurresId)
            ->get();
       foreach($request->seller as $seller){
        if($seller['insurances_id'] == $insurresId){
            $polizaValor = $seller[$time];
        }
       }
        return Inertia::render('Policy/create', [
            'car' => $request->car,
            'sellers' => $request->seller,
            'services' => $services,
            'policyTime' => $time,
            'clien_id' => $request->clien_id,
            'insurres' => $insurres[0],
            'client' => $request->client,
            'tipos' => $request->tipos,
            'marcas' => $request->marcas,
            'modelos' => $request->modelos,
            'car' => $request->car,
            'polizaValor' => $polizaValor,
            'cities' => $request->cities,
            'provinces' => $request->provinces,
            'clientProvince' => $request->clientProvince
        ]);
    }
    public function carReturn(Request $request)
    {
        return Inertia::render('Vehiculo/index', [
            'cities' => $request->cities,
            'provinces' => $request->provinces,
            'clientProvince' => $request->clientProvince, 
            'client' => $request->client,
            'tipos' => $request->tipos,
            'marcas' => $request->marcas,
            'modelos' => $request->modelos,
            'car' => $request->car
        ]);
    }
    public function caseguradoraReturn(Request $request)
    {
        return Inertia::render('Policy/index', [
            'car' => $request->car,
            'sellers' => $request->sellers,
            'clien_id' => $request->clien_id,
            'cities' => $request->cities,
            'provinces' => $request->provinces,
            'clientProvince' => $request->clientProvince, 
            'client' => $request->client,
            'tipos' => $request->tipos,
            'marcas' => $request->marcas,
            'modelos' => $request->modelos,
        ]);
    }
    public function serviciosReturn(Request $request)
    {
       //return $request->insurre;
        return Inertia::render('Policy/create', [
            'car' => $request->car,
            'sellers' => $request->sellers,
            'clien_id' => $request->clien_id,
            'cities' => $request->cities,
            'provinces' => $request->provinces,
            'clientProvince' => $request->clientProvince, 
            'client' => $request->client,
            'tipos' => $request->tipos,
            'marcas' => $request->marcas,
            'modelos' => $request->modelos,
            'tarifa' => $request->tarifa,
            'services' => $request->services,
            'policyTime' => $request->policyTime,
            'servicios' => $request->servicios,
            'polizaValor' => $request->polizaValor,
            'insurres' => $request->insurre,

        ]);
    }
}
