<template>
    <section class="flex flex-col justify-center items-center text-center py-4 bg-gray-300">
        <div class=" text-gray-700">
            <p>Seguros Chat. Todos los derechos reservados</p>
        </div>
        <div>
            <p class=" text-blue-700">Términos y condiciones <span class="text-gray-700">|</span> Politicas de
                privacidad</p>
        </div>
    </section>
</template>

<script>
export default {
    name: "Footer",
}
</script>