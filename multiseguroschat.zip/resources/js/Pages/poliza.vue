<template>
    <div id="image" class="fondo">
        <!--<img class="text-center w-36" :src="logo">-->
        <div class="border-2 border-sky-500 rounded-md tarjeta">
            <span class="">
                <div class="header_poliza"></div>
                <table class="">
                    <tr>
                        <td>NO. POLIZA:</td>
                        <td>AUTO-AT-027723</td>
                    </tr>
                    <tr>
                        <td>NOMBRES:</td>
                        <td>ANEURYS ALONZO MERCEDES NUNEZ</td>
                    </tr>
                    <tr>
                        <td>VEHICULO:</td>
                        <td>Jeep HYUNDAI</td>
                    </tr>
                    <tr>
                        <td>AÑO:</td>
                        <td>2010</td>
                    </tr>
                    <tr>
                        <td>CHASSIS:</td>
                        <td>KMHSH81BBAU610286</td>
                    </tr>
                    <tr>
                        <td>VIGENCIA:</td>
                        <td>DESDE 05-04-2023 HASTA 05-04-2024 12:00 PM</td>
                    </tr>
                    <tr>
                        <td>FIANZA JUDICIAL:</td>
                        <td>RD$ 300,00</td>
                    </tr>
                </table>
                <div class="foother_poliza"></div>
            </span>
        </div>
    </div>
</template>
<style>
.fondo {
    width: 500px;
    height: 410px;
    display: v-bind(display);
}
.tarjeta {
    width: 500px;
    height: 400px;
}
.header_poliza {
    background-image: url("/images/Atrio-Horizontal-sin-fondo.png");
    background-size: contain !important;
    background-repeat: no-repeat;
    height: 80px;
    width: 500px;
}
.foother_poliza {
    background-image: url("/images/Seguros_Chat-11.png");
    background-size: contain !important;
    background-color: rgb(31, 127, 252);
    background-repeat: no-repeat;
    height: 80px;
    width: 500px;
}
</style>
<script>
import domtoimage from "dom-to-image-more";
import htmlToImage from "html-to-image";
//import { toPng, toJpeg, toBlob, toPixelData, toSvg } from 'html-to-image';
export default {
    data() {
        return {
            display: "contents",
        };
    },
    components: {},
    props: {},
    mounted() {
        var node = document.getElementById("image");

        /* htmlToImage.toPng(node)
            .then(function (dataUrl) {
                var img = new Image();
                img.src = dataUrl;
                document.body.appendChild(img);
            })
            .catch(function (error) {
                console.error('oops, something went wrong!', error);
            });*/

        domtoimage
            .toPng(node)
            .then(function (dataUrl) {
                var ima = new Image();
                ima.src = dataUrl;
                // document.body.appendChild(ima);
                console.log(dataUrl);
            })
            .catch(function (error) {
                console.error("oops, something went wrong!", error);
            });

        setTimeout(() => {
            // this.display = 'none'
        }, 100);
    },
};
</script>
