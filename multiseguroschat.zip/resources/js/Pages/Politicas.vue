<template>
    <section class="max-w-4xl w-full h-full fixed inset-0 mx-auto my-auto p-3 bg-gray-200 shadow-lg z-50 overflow-y-scroll">
        <h1 class="text-center font-bold text-2xl my-8">
            POLÍTICA DE PRIVACIDAD
        </h1>
        <p class="text-justify my-3">
            Bienvenido a nuestra página web. La privacidad de nuestros usuarios
            es muy importante para nosotros, y nos comprometemos a protegerla en
            todo momento. Esta política de privacidad describe cómo recopilamos,
            utilizamos y compartimos tu información personal en nuestro sitio
            web. Al utilizar nuestro sitio web, aceptas los términos de esta
            política de privacidad.
        </p>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                1. Información que recopilamos
            </h3>
            <p class="text-justify">
                Recopilamos información personal como tu nombre, dirección,
                número de teléfono, dirección de correo electrónico, fecha de
                nacimiento, los datos de tus vehículos y otras informaciones
                relevantes para proporcionar nuestros servicios. Además, podemos
                recopilar información de uso del sitio, como tu dirección IP, el
                tipo de dispositivo que estás utilizando, la versión del sistema
                operativo y el navegador web que utilizas.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                2. Uso de la información
            </h3>
            <p class="text-justify">
                Utilizamos la información personal que recopilamos para
                proporcionar nuestros servicios, procesar transacciones,
                responder a preguntas y comentarios, mejorar nuestro sitio web y
                personalizar tu experiencia. Además, podemos utilizar tu
                información personal para enviarte comunicaciones de marketing
                sobre nuestros productos y servicios.
            </p>
        </div>

        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                3. Compartir información
            </h3>
            <p class="text-justify">
                No vendemos, alquilamos ni compartimos tu información personal
                con terceros para fines comerciales. Sin embargo, podemos
                compartir tu información personal con proveedores de servicios y
                otras empresas de seguros para procesar transacciones y brindar
                servicios relacionados con nuestros productos.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                4. Seguridad de la información
            </h3>
            <p class="text-justify">
                Nos comprometemos a proteger la seguridad de tu información
                personal y tomamos medidas razonables para evitar el acceso no
                autorizado, la divulgación y el uso indebido de tu información.
                Sin embargo, ten en cuenta que ningún método de transmisión por
                Internet es 100% seguro y no podemos garantizar la seguridad de
                la información que compartes con nosotros.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">5. Tus derechos</h3>
            <p class="text-justify">
                Tienes derecho a acceder, actualizar o eliminar tu información
                personal en cualquier momento. Si deseas ejercer estos derechos
                o tienes preguntas sobre nuestra política de privacidad,
                contáctanos a través de la información de contacto proporcionada
                en nuestro sitio web.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                6. Cambios en la política de privacidad
            </h3>
            <p class="text-justify">
                Nos reservamos el derecho de modificar esta política de
                privacidad en cualquier momento sin previo aviso. La versión más
                actualizada siempre estará disponible en nuestro sitio web.
            </p>
        </div>
    </section>
</template>
