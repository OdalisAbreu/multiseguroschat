<template>
    <section class="bg-gray-200">
        <Header :width="100" />
        <section class="py-2 pb-6 relative rounded-xl bg-white mx-3 z-40">
            <div class="grid grid-cols-12 gap-1">
                <div class="col-span-12">
                    <h3 class="font-bold text-2xl text-center">
                        Seguro procesado correctamente
                    </h3>
                </div>
            </div>
            <div
                class="flex flex-col justify-center items-center text-center overflow-x-visible"
            >
                <img class="text-center w-36" :src="logo" />
                <iframe
                    :src="
                        'https://multiseguros.com.do/SegurosChat/Admin/Sist.Sucursal/Seguro/poliza.php?id=' +
                        transactionId
                    "
                    width="100%"
                    height="630"
                    frameborder="0"
                >
                </iframe>

                <div class="mt-6">
                    <a
                        class="bg-blue-800 hover:bg-blue-700 shadow-lg shadow-blue-500/50 text-white font-bold rounded-lg w-full py-3 px-6 mt-2 sm:m-3 sm:w-30 md:m-3 md:w-40 xl:m-3 xl:w-50"
                        href="https://api.whatsapp.com/send/?phone=18297624444&text&type=phone_number&app_absent=0"
                        >Ir a WhatsApp
                    </a>
                </div>
            </div>
        </section>
        <Footer class="mt-4" />
    </section>

    <!----------------------------------------------IMAGEN PARA BASE64-------------------->

    <div id="image" class="fondo">
        <div class="border-2 border-sky-500 rounded-md tarjeta">
            <span class="">
                <div class="header_poliza"></div>
                <table class="">
                    <tr>
                        <td>NO. POLIZA:</td>
                        <td>AUTO-AT-027723</td>
                    </tr>
                    <tr>
                        <td>NOMBRES:</td>
                        <td>ANEURYS ALONZO MERCEDES NUNEZ</td>
                    </tr>
                    <tr>
                        <td>VEHICULO:</td>
                        <td>Jeep HYUNDAI</td>
                    </tr>
                    <tr>
                        <td>AÑO:</td>
                        <td>2010</td>
                    </tr>
                    <tr>
                        <td>CHASSIS:</td>
                        <td>KMHSH81BBAU610286</td>
                    </tr>
                    <tr>
                        <td>VIGENCIA:</td>
                        <td>DESDE 05-04-2023 HASTA 05-04-2024 12:00 PM</td>
                    </tr>
                    <tr>
                        <td>FIANZA JUDICIAL:</td>
                        <td>RD$ 300,00</td>
                    </tr>
                </table>
                <div class="foother_poliza"></div>
            </span>
        </div>
    </div>
    <!------------------------------------------------------------------------------------>
</template>

<style scoped>
.fondo {
    width: 500px;
    height: 410px;
    display: v-bind(display);
    background-color: rgb(255, 255, 255);
}
.tarjeta {
    width: 500px;
    height: 400px;
    background-color: rgb(255, 255, 255);
}
.header_poliza {
    background-image: url("/images/Atrio-Horizontal-sin-fondo.png");
    background-size: contain !important;
    background-repeat: no-repeat;
    height: 80px;
    width: 500px;
}
.foother_poliza {
    background-image: url("/images/Seguros_Chat-11.png");
    background-size: contain !important;
    background-color: rgb(31, 127, 252);
    background-repeat: no-repeat;
    height: 80px;
    width: 500px;
}
</style>

<script>
import { defineComponent } from "vue";
import { Head, Link } from "@inertiajs/inertia-vue3";
//import file from "file-saver";
import Header from "../components/Header.vue";
import Footer from "../components/Footer.vue";
import domtoimage from "dom-to-image-more";

export default defineComponent({
    components: {
        Head,
        Link,
        Header,
        Footer,
    },
    props: {},
    data() {
        return {
            display: "contents",
            image64: [],
        };
    },
    props: {
        ResponseCode: String,
        TransactionID: String,
        RemoteResponseCode: String,
        AuthorizationCode: String,
        RetrivalReferenceNumber: String,
        TxToken: String,
        transactionId: String,
        logo: String,
    },
    mounted() {
        //this.image64 = 'PRueba'
        console.log("ResponseCode: " + this.ResponseCode);
        console.log("TransactionID: " + this.TransactionID);
        console.log("RemoteResponseCode: " + this.RemoteResponseCode);
        console.log("AuthorizationCode: " + this.AuthorizationCode);
        console.log("RetrivalReferenceNumber: " + this.RetrivalReferenceNumber);
        console.log("TxToken: " + this.TxToken);

        //Genera la Imagen en Base64

        var node = document.getElementById("image");
        this.image64 = domtoimage
            .toPng(node)
            .then((dataUrl) => {
                console.log(dataUrl);
                  axios
                    .post("/api/V1/savePolizaImage", {
                        idPoliza: 3,
                        image: dataUrl,
                    })
                    .then((response) => {
                        console.log(esponse.data);
                    })
                    .catch((error) => {
                        console.log(error.response);
                    });
            })
            .catch((error) => {
                console.error("oops, something went wrong!", error);
            });

       /* domtoimage
            .toBlob(document.getElementById("image"))
            .then(function (blob) {
                window.saveAs(blob, "my-node.png");
            });*/

        setTimeout(() => {
            this.display = "none";
        }, 100);

        axios.get(
            "/api/V1/enviarIdPolizaBot/123456/93a124ee-97c8-44d2-8dd1-e597fc0d1916"
        );
    },
});
</script>
