<template>
    <section class="max-w-4xl w-full h-full fixed inset-0 mx-auto my-auto p-3 bg-gray-200 shadow-lg z-50 overflow-y-scroll">
        <h1 class="text-center font-bold text-2xl my-6">
            Términos y condiciones
        </h1>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">1. Servicios</h3>
            <p class="text-justify">
                Nuestra página web ofrece servicios de venta de seguros y
                servicios afines. Nos esforzamos por ofrecer una descripción
                precisa y completa de todos nuestros servicios. Sin embargo, no
                garantizamos que la información en nuestro sitio web esté libre
                de errores. Nos reservamos el derecho de modificar nuestros
                servicios en cualquier momento sin previo aviso.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                2. Uso de nuestro sitio web
            </h3>
            <p class="text-justify">
                Al utilizar nuestro sitio web, aceptas no realizar ninguna
                actividad que sea ilegal, fraudulenta o que infrinja los
                derechos de propiedad intelectual de terceros. Además, aceptas
                no utilizar nuestro sitio web para difundir spam, malware o
                cualquier otra forma de software malicioso.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                3. Propiedad intelectual
            </h3>
            <p class="text-justify">
                Todo el contenido en nuestro sitio web, incluyendo textos,
                gráficos, imágenes y software, son propiedad de nuestra compañía
                o de sus respectivos propietarios de derechos de autor. No se
                permite la reproducción, distribución o modificación de ningún
                contenido sin nuestro consentimiento previo y por escrito.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">4. Privacidad</h3>
            <p class="text-justify">
                Nos comprometemos a proteger tu privacidad en todo momento. Por
                favor, consulta nuestra política de privacidad para obtener más
                información sobre cómo manejamos tus datos personales.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                5. Exención de responsabilidad
            </h3>
            <p class="text-justify">
                No nos hacemos responsables de ningún daño directo, indirecto,
                incidental, especial o consecuente que pueda resultar del uso de
                nuestro sitio web o de nuestros servicios.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                6. Modificaciones a estos términos y condiciones
            </h3>
            <p class="text-justify">
                Nos reservamos el derecho de modificar estos términos y
                condiciones en cualquier momento sin previo aviso. La versión
                más actualizada siempre estará disponible en nuestro sitio web.
            </p>
        </div>
        <div class="my-2">
            <h3 class="text-left mb-2 text-lg font-bold">
                7. Ley aplicable y jurisdicción
            </h3>
            <p class="text-justify">
                Estos términos y condiciones se regirán e interpretarán de
                acuerdo con las leyes de [país]. Cualquier disputa relacionada
                con estos términos y condiciones se resolverá exclusivamente en
                los tribunales de la República Dominicana .
            </p>
        </div>
    </section>
</template>
